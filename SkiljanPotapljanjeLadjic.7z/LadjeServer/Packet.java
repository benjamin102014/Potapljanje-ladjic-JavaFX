import java.io.Serializable;

public class Packet implements Serializable{
    private boolean[][] tabState;
    private int[] x;
    private int[] y;
    private boolean resetSignal;
    
    public Packet(){
    }
    public Packet(boolean[][] tabState){
        this.tabState = tabState;
    }
    public Packet(int[] x, int[] y){
        this.x = x;
        this.y = y;
    }
    public Packet(boolean resetSignal){
        this.resetSignal = resetSignal;
    }
    
    public void setTabState(boolean[][] tabState){
        this.tabState = tabState;
    }
    public boolean[][] getTabState(){
        return this.tabState;
    }
    public void setX(int[] x){
        this.x = x;
    }
    public int[] getX(){
        return this.x;
    }
    public void setY(int[] y){
        this.y = y;
    }
    public int[] getY(){
        return this.y;
    }
    public void setResetSignal(boolean resetSignal){
        this.resetSignal = resetSignal;
    }
    public boolean getResetSignal(){
        return this.resetSignal;
    }
}