import java.io.*;
import java.net.*;
public class Server{
    static final int port = 1111;
    static Packet packet1;
    static Packet packet2;
    static volatile Object threadMonitor1 = new Object();
    static volatile Object threadMonitor2 = new Object();
    static volatile boolean notify1 = false;
    static volatile boolean notify2 = false;
    static volatile int threadCount = 1;
    static volatile boolean thread1Done = false;
    static volatile boolean thread2Done = false;
    static volatile boolean thread1Responded = false;
    static volatile boolean thread2Responded = false;
    static volatile Object threadCheck = new Object();
    public static void main(String[] args){
        try(
            ServerSocket serverSocket = new ServerSocket(port)
        ){
            new Sender1().start();
            new Sender2().start();
            while (true) {
                Socket socket = serverSocket.accept();
                new EchoThread(socket, threadCount).start();
                threadCount++;
            }
        } catch(Exception e){
            e.printStackTrace();
        }
    }
}
class Sender1 extends Thread{
    public void run(){
        while(true){
            if(Server.threadCount==3){
                if(Server.packet1!=null && Server.packet2!=null){
                    Server.notify1 = true;
                    synchronized(Server.threadMonitor1){
                        Server.threadMonitor1.notifyAll();
                        while(!Server.thread1Responded){
                            try{
                                Server.threadMonitor1.wait();
                            } catch (Exception e){
                                e.printStackTrace();
                            }
                        }
                        Server.thread1Responded = false;
                    }
                }
            }
        }
    }
}
class Sender2 extends Thread{
    public void run(){
        while(true){
            if(Server.threadCount==3){
                if(Server.packet1!=null && Server.packet2!=null){
                    Server.notify2 = true;
                    synchronized(Server.threadMonitor2){
                        Server.threadMonitor2.notifyAll();
                        while(!Server.thread2Responded){
                            try{
                                Server.threadMonitor2.wait();
                            } catch (Exception e){
                                e.printStackTrace();
                            }
                        }
                        Server.thread2Responded = false;
                    }
                }
            }
        }
    }
}



class EchoThread extends Thread {
    volatile protected Socket socket;
    volatile protected int player;
    
    public EchoThread(Socket clientSocket, int player) {
        this.socket = clientSocket;
        this.player = player;
    }

    public void run() {
        try (
            ObjectInputStream in = new ObjectInputStream(socket.getInputStream());
            ObjectOutputStream out = new ObjectOutputStream(socket.getOutputStream())
        ){
            if(player == 1){
                synchronized(Server.threadMonitor1){
                    while(true){
                        Server.thread1Done = false;
                        
                        Server.packet1 = (Packet) in.readObject();
                        
                        while(!Server.notify1){
                            Server.threadMonitor1.wait();
                        }
                        Server.notify1 = false;
                        
                        out.writeObject(Server.packet2);
                        
                        synchronized(Server.threadCheck){
                            Server.thread1Done = true;
                            if(Server.thread2Done){
                                synchronized(Server.threadMonitor2){
                                    Server.threadMonitor2.notifyAll();
                                }
                            }
                        }
                        if(!Server.thread2Done){
                            Server.threadMonitor1.wait();
                        }
                        
                        Server.packet2 = null;
                        
                        Server.thread1Responded = true;
                        Server.threadMonitor1.notifyAll();
                    }
                }
            }
            if(player == 2){
                synchronized(Server.threadMonitor2){
                    while(true){
                        Server.thread2Done = false;
                        
                        Server.packet2 = (Packet) in.readObject();
                            
                        while(!Server.notify2){
                            Server.threadMonitor2.wait();
                        }
                        Server.notify2 = false;
                        
                        out.writeObject(Server.packet1);
                        
                        synchronized(Server.threadCheck){
                            Server.thread2Done = true;
                            if(Server.thread1Done){
                                synchronized(Server.threadMonitor1){
                                    Server.threadMonitor1.notifyAll();
                                }
                            }
                        }
                        if(!Server.thread1Done) {
                            Server.threadMonitor2.wait();
                        }
                        
                        Server.packet1 = null;
                        
                        Server.thread2Responded = true;
                        Server.threadMonitor2.notifyAll();
                    }
                }
            }
        } catch (EOFException eofe){
            //ne gre drugače
        } catch (Exception e) {
            e.printStackTrace();
            return;
        }
    }
}