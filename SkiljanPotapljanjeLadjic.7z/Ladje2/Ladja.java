public class Ladja{
    char orientacija; //'s'-gor 'j'-dol 'v'-desno 'z'-levo
    int xK;
    int yK;
    int dolzina;
    Ladja(){
    }
    Ladja(int dolzina){
        this.dolzina = dolzina;
    }
    
    
    /**GET Method Propertie orientacija*/
    public char getOrientacija(){
        return this.orientacija;
    }//end method getOrientacija

    /**SET Method Propertie orientacija*/
    public void setOrientacija(char orientacija){
        this.orientacija = orientacija;
    }//end method setOrientacija

    /**GET Method Propertie xK*/
    public int getXK(){
        return this.xK;
    }//end method getXK

    /**SET Method Propertie xK*/
    public void setXK(int xK){
        this.xK = xK;
    }//end method setXK

    /**GET Method Propertie yK*/
    public int getYK(){
        return this.yK;
    }//end method getYK

    /**SET Method Propertie yK*/
    public void setYK(int yK){
        this.yK = yK;
    }//end method setYK

    /**GET Method Propertie dolzina*/
    public int getDolzina(){
        return this.dolzina;
    }//end method getDolzina

    /**SET Method Propertie dolzina*/
    public void setDolzina(int dolzina){
        this.dolzina = dolzina;
    }//end method setDolzina
}//End class