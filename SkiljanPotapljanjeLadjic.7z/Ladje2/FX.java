
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.Group;
import javafx.geometry.Insets;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Pane;
import javafx.scene.shape.Rectangle;
import javafx.stage.Stage;
import javafx.scene.paint.Color;
import javafx.scene.text.Text;
import javafx.scene.input.MouseEvent;
import java.io.*;
import java.net.*;
import javafx.concurrent.*;
import javafx.application.Platform;
/**
 * Write a description of JavaFX class FX here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class FX extends Application
{
    private String faza = "place";
    
    char orientacija = 's';
    
    Ladja[] ladje = new Ladja[5];
    int idLadje = 0;
    
    static int shotCount = 0;
    static volatile int[] tabShotX = new int[5];
    static volatile int[] tabShotY = new int[5];
    static volatile int[] tabShotXEnemy = new int[5];
    static volatile int[] tabShotYEnemy = new int[5];
    static boolean attackDone = true;
    
    static int hitCountOwn = 0;
    static int hitCountEnemy = 0;
    
    static boolean[][] tabState = new boolean[10][10];
    static boolean[][] tabStateEnemy = new boolean[10][10];
    
    static int roundCount = 0;
    static boolean gameOver = false;
    
    static Button reset;
    static Pane root;
    
    static boolean stopReadResetSignal = false;
    
    static Socket socket = null;
    static ObjectOutputStream out = null;
    static ObjectInputStream in = null;
    /**
     * The start method is the main entry point for every JavaFX application. 
     * It is called after the init() method has returned and after 
     * the system is ready for the application to begin running.
     *
     * @param  stage the primary stage for this application.
     */
    @Override
    public void start(Stage stage)
    {
        try{
            socket = new Socket("localhost", 1111);
            out = new ObjectOutputStream(socket.getOutputStream());
            in = new ObjectInputStream(socket.getInputStream());
            
            // Create a new grid pane
            GridPane pane = new GridPane();
            pane.setPadding(new Insets(10, 10, 10, 10));
            pane.setMinSize(300, 300);
    
            ladje[0] = new Ladja(2); //nastavljanje dolzin
            ladje[1] = new Ladja(3);
            ladje[2] = new Ladja(3);
            ladje[3] = new Ladja(4);
            ladje[4] = new Ladja(5);
            
            Text legendaText = new Text("Legenda:");
            legendaText.setLayoutX(600);
            legendaText.setLayoutY(50);
            legendaText.setStyle("-fx-font-size: 24px;");
            
            Rectangle r1 = new Rectangle(600,70,20,20);
            r1.setFill(Color.GREEN);
            r1.setStroke(Color.BLACK);
            
            Text green = new Text("Ladje igralca");
            green.setLayoutX(650);
            green.setLayoutY(87);
            green.setStyle("-fx-font-size: 20px;");
            
            Rectangle r2 = new Rectangle(600,100,20,20);
            r2.setFill(Color.LAWNGREEN);
            r2.setStroke(Color.BLACK);
            
            Text lawngreen = new Text("Tarča strela");
            lawngreen.setLayoutX(650);
            lawngreen.setLayoutY(117);
            lawngreen.setStyle("-fx-font-size: 20px;");
            
            Rectangle r3 = new Rectangle(600,130,20,20);
            r3.setFill(Color.RED);
            r3.setStroke(Color.BLACK);
            
            Text red = new Text("Zadet strel");
            red.setLayoutX(650);
            red.setLayoutY(147);
            red.setStyle("-fx-font-size: 20px;");
            
            Rectangle r4 = new Rectangle(600,160,20,20);
            r4.setFill(Color.LIGHTSKYBLUE);
            r4.setStroke(Color.BLACK);
            
            Text lightskyblue = new Text("Voda, zgrešen strel igralca");
            lightskyblue.setLayoutX(650);
            lightskyblue.setLayoutY(177);
            lightskyblue.setStyle("-fx-font-size: 20px;");
            
            Rectangle r5 = new Rectangle(600,190,20,20);
            r5.setFill(Color.DIMGRAY);
            r5.setStroke(Color.BLACK);
            
            Text dimgray = new Text("Zgrešen strel nasprotnika");
            dimgray.setLayoutX(650);
            dimgray.setLayoutY(207);
            dimgray.setStyle("-fx-font-size: 20px;");
            
            Rectangle r6 = new Rectangle(600,220,20,20);
            r6.setFill(Color.WHITE);
            r6.setStroke(Color.BLACK);
            
            Text white = new Text("Neraziskana polja");
            white.setLayoutX(650);
            white.setLayoutY(237);
            white.setStyle("-fx-font-size: 20px;");
            
            Text smeri = new Text("\nČrka na sredini predstavlja orientacijo\nnaslednje postavljene ladje:\n\nS: sever\nV: vzhod\nJ: jug\nZ: zahod");
            smeri.setLayoutX(650);
            smeri.setLayoutY(267);
            smeri.setStyle("-fx-font-size: 20px;");
            
            Group legenda = new Group();
            legenda.getChildren().add(legendaText);
            legenda.getChildren().add(r1);
            legenda.getChildren().add(green);
            legenda.getChildren().add(r2);
            legenda.getChildren().add(lawngreen);
            legenda.getChildren().add(r3);
            legenda.getChildren().add(red);
            legenda.getChildren().add(r4);
            legenda.getChildren().add(lightskyblue);
            legenda.getChildren().add(r5);
            legenda.getChildren().add(dimgray);
            legenda.getChildren().add(r6);
            legenda.getChildren().add(white);
            legenda.getChildren().add(smeri);   
            
            Text status = new Text("Status:\nPostavljanje ladjic");
            status.setLayoutX(280);
            status.setLayoutY(50);
            status.setStyle("-fx-font-size: 24px;");
            
            Text hitCountOwnStatus = new Text("0/17");
            hitCountOwnStatus.setLayoutX(230);
            hitCountOwnStatus.setLayoutY(50);
            hitCountOwnStatus.setStyle("-fx-font-size: 20px;");
            
            Text hitCountEnemyStatus = new Text("0/17");
            hitCountEnemyStatus.setLayoutX(230);
            hitCountEnemyStatus.setLayoutY(270);
            hitCountEnemyStatus.setStyle("-fx-font-size: 20px;");
            
            
            
            
            Rectangle[][] enemyGrid = new Rectangle[10][10];
            Rectangle[][] ownGrid = new Rectangle[10][10];
            for(int x=0;x<10;x++){
                for(int y=0;y<10;y++){
                    Rectangle r = new Rectangle(x*20,y*20,20,20);
                    r.setFill(Color.WHITE);
                    r.setStroke(Color.BLACK);
                    enemyGrid[x][y] = r;
    
                    r.setOnMouseClicked(new EventHandler<MouseEvent>(){
                        @Override
                        public void handle(MouseEvent t) {
                            if(faza=="attack" && attackDone && !gameOver){
                                if(shotCount<5){
                                    if(r.getFill()==Color.WHITE){
                                        r.setFill(Color.LAWNGREEN);
                                        tabShotX[shotCount] = (int)r.getX()/20;
                                        tabShotY[shotCount] = (int)r.getY()/20;
                                        shotCount++;
                                    }
                                }
                                if(shotCount==5){
                                    attackDone = false;
                                    try{
                                        Packet attackPacket = new Packet(tabShotX, tabShotY);
                                        
                                        out.flush();
                                        out.reset();
                                        
                                        out.writeObject(attackPacket);
                                    } catch (Exception e){
                                        e.printStackTrace();
                                    }
                                    
                                    
                                    Task<Void> readAttackTask = new Task<Void>(){
                                        @Override protected Void call() throws Exception {
                                            try{
                                                while(true){
                                                    Packet readPacket = (Packet) in.readObject();
                                                    tabShotXEnemy = readPacket.getX();
                                                    tabShotYEnemy = readPacket.getY();
                                                    
                                                    Platform.runLater(new Runnable(){
                                                        public void run() {
                                                            paintEnemy(enemyGrid, tabStateEnemy, tabShotX, tabShotY);
                                                            paintOwn(ownGrid, tabState, tabShotXEnemy, tabShotYEnemy);
                                                            
                                                            roundCount++;
                                                            status.setText("Status:\nNapadanje ladjic\nRunda: "+roundCount);
                                                            hitCountEnemy = updateHitCountEnemy(hitCountEnemy, tabState, tabShotXEnemy, tabShotYEnemy);
                                                            hitCountOwn = updateHitCountOwn(hitCountOwn, tabStateEnemy, tabShotX, tabShotY);
                                                            
                                                            hitCountOwnStatus.setText(hitCountOwn+"/17");
                                                            hitCountEnemyStatus.setText(hitCountEnemy+"/17");
                                                            
                                                            if(hitCountOwn==17 && hitCountEnemy==17){
                                                                gameOver = true;
                                                                status.setText("Status:\nKonec igre\nIzenačeno");
                                                                root.getChildren().remove(hitCountOwnStatus);
                                                                root.getChildren().remove(hitCountEnemyStatus);
                                                                root.getChildren().add(reset);
                                                                return;
                                                            }
                                                            if(hitCountEnemy==17){
                                                                gameOver = true;
                                                                status.setText("Status:\nKonec igre\nPoraz");
                                                                root.getChildren().remove(hitCountOwnStatus);
                                                                root.getChildren().remove(hitCountEnemyStatus);
                                                                root.getChildren().add(reset);
                                                                return;
                                                            }
                                                            if(hitCountOwn==17){
                                                                gameOver = true;
                                                                status.setText("Status:\nKonec igre\nZmaga");
                                                                root.getChildren().remove(hitCountOwnStatus);
                                                                root.getChildren().remove(hitCountEnemyStatus);
                                                                root.getChildren().add(reset);
                                                                return;
                                                            }
                                                        }
                                                    });
                                                    
                                                    shotCount = 0;
                                                    attackDone = true;
                                                    
                                                    break;
                                                }
                                            } catch (EOFException eof){
                                                //nič
                                            } catch (Exception e){
                                                e.printStackTrace();
                                            }
                                            return null;
                                        }
                                    };
                                    new Thread(readAttackTask).start();
                                }
                            }
                        }
                    });
                    
                    pane.add(enemyGrid[x][y], x, y);
                }
            }
            pane.addRow(10,new Text(""));
            
            for(int x=0;x<10;x++){
                for(int y=0;y<10;y++){
                    Rectangle r = new Rectangle(x*20,y*20,20,20);
                    r.setFill(Color.LIGHTSKYBLUE);
                    r.setStroke(Color.BLACK);
                    ownGrid[x][y] = r;
    
                    r.setOnMouseClicked(new EventHandler<MouseEvent>(){
                        @Override
                        public void handle(MouseEvent t) {
                            if(idLadje!=5 && faza=="place"){
                                if(placeable((int)r.getX()/20, (int)r.getY()/20, ladje[idLadje].getDolzina(), orientacija, r)){
                                    place((int)r.getX()/20, (int)r.getY()/20, orientacija);
                                    paint(ownGrid, r, ladje[idLadje].getOrientacija());
                                    idLadje++;
                                    if(idLadje==5){
                                        try{
                                            Packet writePacket = new Packet(tabState);
                                            
                                            out.flush();
                                            out.reset();
                                            
                                            out.writeObject(writePacket);
                                            
                                            Task<Void> readTabStateEnemyTask = new Task<Void>(){
                                            @Override protected Void call() throws Exception {
                                                try{
                                                    status.setText("Status:\nČakanje na nasprotnika");
                                                        while(true){
                                                            Packet readPacket = (Packet) in.readObject();
                                                            tabStateEnemy = readPacket.getTabState();
                                                            idLadje=0;
                                                            faza="attack";
                                                            status.setText("Status:\nNapadanje ladjic\nRunda: "+roundCount);
                                                            Platform.runLater(new Runnable(){
                                                                public void run() {
                                                                    root.getChildren().add(hitCountOwnStatus);
                                                                    root.getChildren().add(hitCountEnemyStatus);
                                                                    hitCountOwnStatus.setText(hitCountOwn+"/17");
                                                                    hitCountEnemyStatus.setText(hitCountEnemy+"/17");
                                                                }
                                                            });
                                                            break;
                                                        }
                                                    } catch (EOFException eof){
                                                        //nič
                                                    } catch (Exception e){
                                                        e.printStackTrace();
                                                    }
                                                    return null;
                                                }
                                            };
                                            new Thread(readTabStateEnemyTask).start();
                                            
                                        }catch(Exception e){
                                            e.printStackTrace();
                                        }
                                    }
                                }
                            }
                        }
                    });
    
                    
                    pane.add(ownGrid[x][y], x, y+11);
                }
            }
    
            Text orientacijaText = new Text(String.valueOf(orientacija).toUpperCase());
            orientacijaText.setLayoutX(404);
            orientacijaText.setLayoutY(258);
            orientacijaText.setStyle("-fx-font-size: 24px;");
            
            
            Button btnS = new Button();
            btnS.setText("^");
            btnS.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent event) {
                    orientacija = 's';
                    orientacijaText.setText("S");
                }
            });
            btnS.setLayoutX(400);
            btnS.setLayoutY(140);
            
            Button btnV = new Button();
            btnV.setText(">");
            btnV.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent event) {
                    orientacija = 'v';
                    orientacijaText.setText("V");
                }
            });
            btnV.setLayoutX(500);
            btnV.setLayoutY(240);
            
            Button btnJ = new Button();
            btnJ.setText("V");
            btnJ.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent event) {
                    orientacija = 'j';
                    orientacijaText.setText("J");
                }
            });
            btnJ.setLayoutX(400);
            btnJ.setLayoutY(340);
            
            Button btnZ = new Button();
            btnZ.setText("<");
            btnZ.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent event) {
                    orientacija = 'z';
                    orientacijaText.setText("Z");
                }
            });
            btnZ.setLayoutX(300);
            btnZ.setLayoutY(240);
            
            Group orientacijaGumbi = new Group();
            orientacijaGumbi.getChildren().add(btnS);
            orientacijaGumbi.getChildren().add(btnV);
            orientacijaGumbi.getChildren().add(btnJ);
            orientacijaGumbi.getChildren().add(btnZ);
            
            reset = new Button();
            reset.setText("Reset");
            reset.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent event) {
                    try{
                        Packet sendResetSignal = new Packet(true);
                        
                        out.flush();
                        out.reset();
                        
                        out.writeObject(sendResetSignal);
                    }
                    catch (Exception e){
                        e.printStackTrace();
                    }
                    
                    Task<Void> waitReset = new Task<Void>(){
                        @Override protected Void call() throws Exception {
                            try{
                                status.setText("Status:\nČakanje na reset nasprotnika");
                                while(true){
                                    Packet readResetSignal = (Packet) in.readObject();
                                    if(readResetSignal.getResetSignal()){
                                        reset(enemyGrid, ownGrid);                                  //reset vseh spremenljivk
                                        status.setText("Status:\nPostavljanje ladjic");
                                        
                                        Platform.runLater(new Runnable(){
                                            public void run() {
                                                root.getChildren().remove(reset);
                                        }
                                        });
                                    }
                                    break;
                                }
                            } catch (EOFException eof){
                                //nič
                            } catch (Exception e){
                                e.printStackTrace();
                            }
                            return null;
                        }
                    };
                    new Thread(waitReset).start();
                }
            });
            reset.setLayoutX(395);
            reset.setLayoutY(450);
            
            root = new Pane();
            root.getChildren().add(pane);
            root.getChildren().add(orientacijaGumbi);
            root.getChildren().add(orientacijaText);
            root.getChildren().add(legenda);
            root.getChildren().add(status);
            
                     
            
            
            // JavaFX must have a Scene (window content) inside a Stage (window)
            Scene scene = new Scene(root, 1000,500);
            stage.setTitle("JavaFX Example");
            stage.setScene(scene);
    
            // Show the Stage (window)
            stage.show();
        } catch(Exception e){
            e.printStackTrace();
        }
    }
    private void reset(Rectangle[][] enemyGrid, Rectangle[][] ownGrid){
        gameOver = false;
        roundCount = 0;
        hitCountEnemy = 0;
        hitCountOwn = 0;
        shotCount = 0;
        idLadje = 0;
        orientacija = 's';
        faza = "place";
        for(int i=0; i<5; i++){
            tabShotX[i] = 0;
            tabShotY[i] = 0;
        }
        for(int x=0; x<10; x++){
            for(int y=0; y<10; y++){
                tabState[x][y] = false;
                enemyGrid[x][y].setFill(Color.WHITE);
                ownGrid[x][y].setFill(Color.LIGHTSKYBLUE);
            }
        }
    }
    
    private void place(int x, int y, char orientacija){
        if(idLadje<5){
            ladje[idLadje].setXK(x);
            ladje[idLadje].setYK(y);
            ladje[idLadje].setOrientacija(orientacija);
        }
    }
    private void paint(Rectangle[][] ownGrid, Rectangle r, char orientacija){
        int x = (int)r.getX()/20;
        int y = (int)r.getY()/20;
        switch(orientacija){
            case 's':                
                paintS(ownGrid, x, y);
                break;
            case 'j':
                paintJ(ownGrid, x, y);
                break;
            case 'v':
                paintV(ownGrid, x, y);
                break;
            case 'z':
                paintZ(ownGrid, x, y);
                break;
        }
    }
    private void paintS(Rectangle[][] ownGrid, int x, int y){
        for(int i=0;i<ladje[idLadje].getDolzina();i++){
            ownGrid[x][y].setFill(Color.GREEN);
            updateTabState(x,y);
            y--;
        }
    }
    private void paintJ(Rectangle[][] ownGrid, int x, int y){
        for(int i=0;i<ladje[idLadje].getDolzina();i++){
            ownGrid[x][y].setFill(Color.GREEN);
            updateTabState(x,y);
            y++;
        }
    }
    private void paintV(Rectangle[][] ownGrid, int x, int y){
        for(int i=0;i<ladje[idLadje].getDolzina();i++){
            ownGrid[x][y].setFill(Color.GREEN);
            updateTabState(x,y);
            x++;
        }
    }
    private void paintZ(Rectangle[][] ownGrid, int x, int y){
        for(int i=0;i<ladje[idLadje].getDolzina();i++){
            ownGrid[x][y].setFill(Color.GREEN);
            updateTabState(x,y);
            x--;
        }
    }
    private void updateTabState(int x, int y){
        tabState[x][y] = true;
    }
    
    
    
    private boolean placeable(int x, int y, int dolzina, char orientacija, Rectangle r){
        if(izvenTabele(x, y, dolzina, orientacija)) return false;
        switch (orientacija) {
            case 's':
                if(oviraS(x, y, 0)) return false;
                if(oviraOkoliS(x, y)) return false;
                break;
            case 'j':
                if(oviraJ(x, y, 0)) return false;
                if(oviraOkoliJ(x, y)) return false;
                break;
            case 'v':
                if(oviraV(x, y, 0)) return false;
                if(oviraOkoliV(x, y)) return false;
                break;
            case 'z':
                if(oviraZ(x, y, 0)) return false;
                if(oviraOkoliZ(x, y)) return false;
                break;
        }
        return true;
    }
    
    private boolean oviraOkoliS(int x, int y){
        try{
            if(tabState[x-1][y+1]==true) return true;
        } catch (Exception e){}
        try{
            if(tabState[x][y+1]==true) return true;
        } catch (Exception e){}
        try{
            if(tabState[x+1][y+1]==true) return true;
        } catch (Exception e){}
        
        int tempY;
        try{
            tempY=y;
            for(int i=0; i<ladje[idLadje].getDolzina()+1; i++){
                if(tabState[x-1][tempY]==true) return true;
                tempY--;
            }
        } catch(Exception e){}
        try{
            tempY=y;
            for(int i=0; i<ladje[idLadje].getDolzina()+1; i++){
                if(tabState[x+1][tempY]==true) return true;
                tempY--;
            }
        } catch(Exception e){}
        return false;
    }
    private boolean oviraOkoliJ(int x, int y){
        try{
            if(tabState[x-1][y-1]==true) return true;
        } catch (Exception e){}
        try{
            if(tabState[x][y-1]==true) return true;
        } catch (Exception e){}
        try{
            if(tabState[x+1][y-1]==true) return true;
        } catch (Exception e){}
        
        int tempY;
        try{
            tempY=y;
            for(int i=0; i<ladje[idLadje].getDolzina()+1; i++){
                if(tabState[x-1][tempY]==true) return true;
                tempY++;
            }
        } catch(Exception e){}
        try{
            tempY=y;
            for(int i=0; i<ladje[idLadje].getDolzina()+1; i++){
                if(tabState[x+1][tempY]==true) return true;
                tempY++;
            }
        } catch(Exception e){}
        return false;
    }
    private boolean oviraOkoliV(int x, int y){
        try{
            if(tabState[x-1][y-1]==true) return true;
        } catch (Exception e){}
        try{
            if(tabState[x-1][y]==true) return true;
        } catch (Exception e){}
        try{
            if(tabState[x-1][y+1]==true) return true;
        } catch (Exception e){}
        
        int tempX;
        try{
            tempX=x;
            for(int i=0; i<ladje[idLadje].getDolzina()+1; i++){
                if(tabState[tempX][y-1]==true) return true;
                tempX++;
            }
        } catch(Exception e){}
        try{
            tempX=x;
            for(int i=0; i<ladje[idLadje].getDolzina()+1; i++){
                if(tabState[tempX][y+1]==true) return true;
                tempX++;
            }
        } catch(Exception e){}
        return false;
    }
    private boolean oviraOkoliZ(int x, int y){
        try{
            if(tabState[x+1][y-1]==true) return true;
        } catch (Exception e){}
        try{
            if(tabState[x+1][y]==true) return true;
        } catch (Exception e){}
        try{
            if(tabState[x+1][y+1]==true) return true;
        } catch (Exception e){}
        
        int tempX;
        try{
            tempX=x;
            for(int i=0; i<ladje[idLadje].getDolzina()+1; i++){
                if(tabState[tempX][y-1]==true) return true;
                tempX--;
            }
        } catch(Exception e){}
        try{
            tempX=x;
            for(int i=0; i<ladje[idLadje].getDolzina()+1; i++){
                if(tabState[tempX][y+1]==true) return true;
                tempX--;
            }
        } catch(Exception e){}
        return false;
    }
    private boolean oviraS(int x, int y, int count){
        try{
            if(tabState[x][y]==true) {
                return true;
            }
        } catch(Exception e){}
        if(ladje[idLadje].getDolzina()==count){
            return false;
        }
        return oviraS(x, y-1, count+1);
    }
    private boolean oviraJ(int x, int y, int count){
        try{
            if(tabState[x][y]==true) {
                return true;
            }
        } catch(Exception e){}
        if(ladje[idLadje].getDolzina()==count){
            return false;
        }
        return oviraJ(x, y+1, count+1);
    }
    private boolean oviraV(int x, int y, int count){
        try{
            if(tabState[x][y]==true) {
                return true;
            }
        } catch(Exception e){}
        if(ladje[idLadje].getDolzina()==count){
            return false;
        }
        return oviraV(x+1, y, count+1);
    }
    private boolean oviraZ(int x, int y, int count){
        try{
            if(tabState[x][y]==true) {
                return true;
            }
        } catch(Exception e){}
        if(ladje[idLadje].getDolzina()==count){
            return false;
        }
        return oviraZ(x-1, y, count+1);
    }
    private boolean izvenTabele(int x, int y, int dolzina, char orientacija){
        if(orientacija=='s' && dolzina<=y+1)
            return false;
        if(orientacija=='j' && dolzina<=(9-y)+1)
            return false;
        if(orientacija=='z' && dolzina<=x+1)
            return false;
        if(orientacija=='v' && dolzina<=(9-x)+1)
            return false;
        return true;
    }
    
    private void paintEnemy(Rectangle[][] enemyGrid, boolean[][] tabStateEnemy, int[] tabShotX, int[] tabShotY){
        for(int i=0; i<5; i++){
            if(tabStateEnemy[tabShotX[i]][tabShotY[i]]==true){
                enemyGrid[tabShotX[i]][tabShotY[i]].setFill(Color.RED);
            } else {
                enemyGrid[tabShotX[i]][tabShotY[i]].setFill(Color.LIGHTSKYBLUE);
            }
        }
    }
    private void paintOwn(Rectangle[][] ownGrid, boolean[][] tabState, int[] tabShotXEnemy, int[] tabShotYEnemy){
        for(int i=0; i<5; i++){
            if(tabState[tabShotXEnemy[i]][tabShotYEnemy[i]]==true){
                ownGrid[tabShotXEnemy[i]][tabShotYEnemy[i]].setFill(Color.RED);
            } else {
                ownGrid[tabShotXEnemy[i]][tabShotYEnemy[i]].setFill(Color.DIMGRAY);
            }
        }
    }
    
    private int updateHitCountEnemy(int hitCountEnemy, boolean[][] tabState, int[] tabShotXEnemy, int[] tabShotYEnemy){
        for(int i=0; i<5; i++){
            if(tabState[tabShotXEnemy[i]][tabShotYEnemy[i]]==true){
                hitCountEnemy++;
            }
        }
        return hitCountEnemy;
    }
    private int updateHitCountOwn(int hitCountOwn, boolean[][] tabStateEnemy, int[] tabShotX, int[] tabShotY){
        for(int i=0; i<5; i++){
            if(tabStateEnemy[tabShotX[i]][tabShotY[i]]==true){
                hitCountOwn++;
            }
        }
        return hitCountOwn;
    }
}
